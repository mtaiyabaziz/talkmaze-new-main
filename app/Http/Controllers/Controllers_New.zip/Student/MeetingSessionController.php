<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\MeetingSession;
use App\Review;

class MeetingSessionController extends Controller
{
    public function list()
    {
    	$list = MeetingSession::where("student_id", auth()->user()->id)
    		->get();
    	return view("student.session.list", get_defined_vars());
    }

    public function addReview($id = null)
    {
    	return view("student.session.review", get_defined_vars());
    }

    public function saveReview(Request $req)
    {
        $req->validate(['rating' => 'required', 
            'review' => 'required']);
        $data = [
            'meeting_session_id' => $req->session_id,
            'user_id' => auth()->user()->id,
            'rating' => $req->rating,
            'review' => $req->review,
        ];

        Review::create($data);
        return redirect()->route("student.session.list")->with("success", "You Have Submitted Your Review Successfully!");
    }

    public function requestRefund($id = null)
    {
        $session = MeetingSession::findOrFail($id);
        $session->refund_status = 1;
        $session->save();
        return back()->with("success", "Your Request For Refund Payment Sent Successfully!");
    }
}
