<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\CoachRequest;
use Yajra\Datatables\Datatables;

class CoachRequestController extends Controller
{
    public function index(Request $request)
    {
        if($req->ajax()){

            $sessions = MeetingSession::select(['id', 'zoom_id', 'session_id', 'student_id' ,'tutor_id','time_taken', 'status', 'student_joined', 'created_at', 'updated_at']);
            return Datatables::of($sessions)
                ->addColumn('action', function ($sessions) {
                    return view('admin.actions.actions_session', get_defined_vars());
                })
                ->editColumn('id', 'ID: {{$id}}')
                ->make(true);
        }
       return view('admin.coach.index');
    }
}
