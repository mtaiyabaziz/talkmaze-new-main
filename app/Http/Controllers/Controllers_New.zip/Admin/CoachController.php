<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Yajra\Datatables\Datatables;
use App\TutorEarning;

class CoachController extends Controller
{
    public function index(Request $req)
    {
    	if($req->ajax()){

            $coaches = User::select(['id', 'name', 'email', 'created_at', 'updated_at'])->where("role", "coach");
            return Datatables::of($coaches)
                ->addColumn('action', function ($coaches) {
                    return view('ajax.admin.coach.actions', get_defined_vars());
                })
                ->addColumn('phone', function ($coaches) {
                    return $coaches->profile->phone ?? '';
                })
                ->addColumn('image', function ($coaches) {
                    return view('ajax.admin.coach.image_column', get_defined_vars());
                })
                ->editColumn('id', 'ID: {{$id}}')
                ->make(true);
        }
       return view('admin.coach.index');
    }

    public function payTutorForm(Request $req)
    {
    	$tutor = User::find($req->tutor_id);
    	return view("ajax.admin.coach.pay_tutor_form", get_defined_vars());
    }

    public function payCoach(Request $req)
    {
    	$data = [
	    			'tutor_id' => $req->tutor_id,
	    			'amount' => $req->payment
    			];
    	TutorEarning::create($data);
    	return back()->with("success", "Amount Paid Successfully!");
    }
}
