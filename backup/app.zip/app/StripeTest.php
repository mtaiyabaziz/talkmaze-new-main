<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StripeTest extends Model
{
    protected $table = 'strip_test';
}
