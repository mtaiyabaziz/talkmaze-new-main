<?php

namespace App\Http\Controllers;

use App\NotificationStream;
use Illuminate\Http\Request;

class NotificationStreamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\NotificationStream  $notificationStream
     * @return \Illuminate\Http\Response
     */
    public function show(NotificationStream $notificationStream)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\NotificationStream  $notificationStream
     * @return \Illuminate\Http\Response
     */
    public function edit(NotificationStream $notificationStream)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\NotificationStream  $notificationStream
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, NotificationStream $notificationStream)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\NotificationStream  $notificationStream
     * @return \Illuminate\Http\Response
     */
    public function destroy(NotificationStream $notificationStream)
    {
        //
    }
}
