<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentRating extends Model
{
    //
}
