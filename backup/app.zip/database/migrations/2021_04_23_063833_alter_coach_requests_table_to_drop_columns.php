<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterCoachRequestsTableToDropColumns extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('drop_columns', function (Blueprint $table) {
            DB::statement("ALTER TABLE `coach_requests` DROP `no_of_weeks`, DROP `remaining_weeks`");
            DB::statement("ALTER TABLE `coach_requests` DROP `interval`");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('drop_columns', function (Blueprint $table) {
            //
        });
    }
}
