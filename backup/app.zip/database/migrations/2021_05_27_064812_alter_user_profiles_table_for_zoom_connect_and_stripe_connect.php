<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterUserProfilesTableForZoomConnectAndStripeConnect extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::statement("ALTER TABLE `user_profiles` ADD `zoom_access_token` VARCHAR(250) NULL DEFAULT NULL AFTER `user_id`");
        DB::statement("ALTER TABLE `user_profiles` ADD `stripe_account` VARCHAR(191) NULL DEFAULT NULL AFTER `zoom_access_token` ");
        DB::statement("ALTER TABLE `user_profiles` ADD `is_boarded` BOOLEAN NOT NULL DEFAULT FALSE AFTER `stripe_account`");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
