<!-- Load Stripe.js on your website. -->
<script src="https://js.stripe.com/v3"></script>

<!-- Create a button that your customers click to complete their purchase. Customize the styling to suit your branding. -->
<button
        style="background-color:#6772E5;color:#FFF;padding:8px 12px;border:0;border-radius:4px;font-size:1em"
        id="checkout-button-price_1HPqGDK6lNkBzgTd6ds5yj5V"
        role="link"
        type="button"
>
    Checkout
</button>

<div id="error-message"></div>

<script>
    (function() {
        var stripe = Stripe('pk_test_HdHiRKbHxwraQ1KoESMKTg8i00zn62hoDy');

        var checkoutButton = document.getElementById('checkout-button-price_1HPqGDK6lNkBzgTd6ds5yj5V');

        checkoutButton.addEventListener('click', function() {
            stripe.redirectToCheckout({
                // Make the id field from the Checkout Session creation API response
                // available to this file, so you can provide it as argument here

                sessionId: '{{$session_id->id}}'
            }).then(function (result) {
                // If `redirectToCheckout` fails due to a browser or network
                // error, display the localized error message to your customer
                // using `result.error.message`.
            });
        });

       /* checkoutButton.addEventListener('click', function () {
            // When the customer clicks on the button, redirect
            // them to Checkout.
            stripe.redirectToCheckout({
                lineItems: [{price: 'price_1HPqGDK6lNkBzgTd6ds5yj5V', quantity: 1}],
                mode: 'subscription',
                clientReferenceId: '5555',
                // Do not rely on the redirect to the successUrl for fulfilling
                // purchases, customers may not always reach the success_url after
                // a successful payment.
                // Instead use one of the strategies described in
                // https://stripe.com/docs/payments/checkout/fulfillment
                successUrl: window.location.protocol + '//dev.talkmaze.com/api/stripepaymentsuccess',
                cancelUrl: window.location.protocol + '//dev.talkmaze.com/api/stripepaymentcanceled',
            })
                .then(function (result) {
                    if (result.error) {
                        // If `redirectToCheckout` fails due to a browser or network
                        // error, display the localized error message to your customer.
                        var displayError = document.getElementById('error-message');
                        displayError.textContent = result.error.message;
                    }
                });
        });*/
    })();
</script>