<!------------------Top Section---------------------------->
<!--<section>
    <div class="banner flex justify-content-center">
        <h3 class="text-white text-center">This website is still in its beta phase. If you experience any inconvenience, please send us an email. We appreciate your feedback.</h3>
    </div>
</section>-->
<section class="top-section" style="background-color:#60d0ac;height: auto;">
  <div class="container">
    <div class="row">
      <div class="col-12 m-auto">
        <p class="text-white mt-1 mb-1"> <span class="float-right">hello@talkmaze.com</span></p>
      </div>
    </div>
  </div>
</section>
<!--<span class="font-weight-bold">Toll Free (U.S./CAN) </span>  +1 (800) 914-1477-->
