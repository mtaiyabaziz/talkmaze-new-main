@extends('user.dashboard.layouts.main')

@section('title', 'Post')

@section('content')
    <!---------------------MAin Setion-------------->
    <section>
        <div class="container-fluid ">
            <div class="row">

                <!-------------Colloum 1------------------------>
                @include('user.dashboard.partials.sidebar')

                <!-----------------------------colloum2------------------->
                @if(auth()->user()->tutors->count() >0 || auth()->user()->hasRole('coach') || auth()->user()->enrollments->count() >0)
                    <div class="col-md-8dot4 bg-light">
                    <div class="container-fluid">
                        <div class="row ">
                            <div class="col-md-4">
                                <h3 class="color-1 mt-3 font-weight-normal">Dashboard</h3>
                                <h6 class="color-1">Welcome to the @if(auth()->user()->hasRole('coach')) Coaching @else Student @endif Dashboard</h6>

                            </div>

                            <div class="col-md-8">
                                <div class="row mt-3 justify-content-end">
                                    <a href="#" class="mr-2" style="display:inline-block;"> <img onclick="myFunction()" class="mt-1 dropbtn " src="images/-e-notifications.png" width="30" height="30">@if($notifications->count()>0)<span id="noti-badge" style="background-color: red; border-radius: 50%;padding: 0px 5px 0px 5px; color: white;">{{ $notifications->count() }}</span>@endif</a>
                                    <form class="mr-3 ml-3">
                                        <a href="{{ url('/dashboard-profile') }}">
                                            <div class="row">
                                                <span class="ml-3 mr-3" style="width:30px; height:30px; overflow:hidden; border-radius:50%; display:inline-block;">
                                                    <img src="{{ auth()->user()->profile->image }}" style="height:100%;" width="100%">
                                                </span>
                                                <span style="display:inline-block;"><p class="text-muted m-auto ml-3">{{ auth()->user()->name }}</p></span>

                                            </div>
                                        </a>
                                    </form>
                                </div>
                            </div>
                            <!----------------------------notification dropdown-------------------->
                            <div id="myDropdown" class="dropdown-content dropdown-menu-right bg-white ">
                                <div class="container">
                                    <div id="1stmodal">
                                        <div   style="height:60vh; width:100%;" class="scroll-f mt-3 mb-3" >
                                            <div class="container-fluid @if($notifications->count()==0) {{ 'h-100' }} @endif" id="notipan">
                                                @forelse($notifications as $fg)
                                                    <a class="p-0 m-0" href="@if($fg->verb == 'SESSION') {{ url('/dashboard-coaching') }} @elseif($fg->verb == 'CHAT') {{ url('/chat/'.$fg->sender->id) }} @elseif($fg->verb == 'COMMENT') {{ url('/forum-detail/'.$fg->action_id) }} @endif">
                                                        <div class="row mt-1" >
                                                            <div class="col-3">
                                                                <img class="mt-3" src="{{ $fg->sender->profile->image }}" width="50">
                                                            </div>
                                                            <div class="col-9">
                                                                <h5 class="mt-2">{{ $fg->sender->name}}{{ $fg->sender->name }}</h5>
                                                                <h6>{{ $fg->action }}</h6>
                                                                <h6 class="h7 color-1">{{ $fg->created_at->diffForHumans() }}</h6>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <hr/>
                                                @empty
                                                    <div class="row justify-content-center" style="display: flex; align-items: center; height: 100% !important;">
                                                        <h3 class="text-muted">No Notification Yet!</h3>
                                                    </div>
                                                @endforelse
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if(auth()->user()->timezone == null)
                        <div class="row justify-content-center">
                            <div class="alert alert-danger" role="alert">
                                Your time is set to <strong>GMT 0</strong> time zone, please <a href="{{ url('/dashboard-profile') }}">Click Here</a> update your time zone by your location
                            </div>
                        </div>
                        @endif
                    <div class="container">

                        <!--------------------------------------------------------------1st card-------------------------->
                        <!--slider-->
                        <section>
                            <div class="center slider pt-2 pb-2 ">
                                @if(auth()->user()->hasRole('user'))
                                    @foreach($sessions as $sc)
                                    <div>
                                        <div class="card shadow-card" style="@if($sc->pivot->status == 1) {{ 'color: white !important; background-color: #69d2b1;' }} @endif">
                                            <div class="text-center">
                                                <div class="card-body">
                                                    <h5 class="text-right text-white" style="float: right;">@if($sc->pivot->status == 1) {{ 'Live' }} @endif</h5>
                                                    <center>
                                                        <div style="width: 100px; height: 100px; overflow: hidden; border-radius: 50%;">
                                                            <img style="object-position: center; object-fit: cover; width: 100%;" height="100%;" width="100%" src="{{$sc->profile->image}}">
                                                        </div>
                                                    </center>
                                                    <h3 class=" mt-3">{{ $sc->name }}</h3>
                                                    <h5 class=" text-muted mt-3" style="@if($sc->pivot->status == 1) {{ 'color: white !important;' }} @endif">Session Time : {{ date('h:i a', strtotime($sc->pivot->ended_at.' '.auth()->user()->timezone.' hours') - strtotime($sc->pivot->created_at.' '.auth()->user()->timezone.' hours')) }}
                                                    </h5>
                                                    <h5 class=" text-muted" style="@if($sc->pivot->status == 1) {{ 'color: white !important;' }} @endif">{{ $sc->pivot->created_at->diffForHumans() }}</h5>
                                                    <h5 class=" text-muted" style="@if($sc->pivot->status == 1) {{ 'color: white !important;' }} @endif">{{ date('d M Y',strtotime($sc->pivot->created_at.' '.auth()->user()->timezone.' hours') ) }}</h5>
                                                    <a class=" color-1" href="{{ url('/dashboard-session/'.$sc->pivot->session_id) }}" style="text-decoration: none; @if($sc->pivot->status == 1) {{ 'color: white !important;' }} @endif" >View Detail</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                                @else
                                    @foreach($scheduals as $sc)
                                        <div>
                                            <div class="card shadow-card">
                                                <div class="text-center">
                                                    <div class="card-body">
                                                        <h5 data-toggle="modal" data-target="#exampleModalenrol{{$sc->id}}" class="text-right text-white" style="float: right;"><i class="fas fa-user" style="color:#69d2b1 !important; cursor:pointer;"></i></h5>
                                                        <center>
                                                            <div style="width: 100px; height: 100px; overflow: hidden; border-radius: 50%;">
                                                                <img style="object-position: center; object-fit: cover; width: 100%;" height="100%;" width="100%" src="{{$sc->image}}">
                                                            </div>
                                                        </center>
                                                        <h3 class=" mt-3">{{ $sc->name }}</h3>
                                                        <h5 class=" text-muted mt-3">Session Date & Time <br/>
                                                            {{ date('Y-m-d h:i a', strtotime($sc->date_time. ' '. auth()->user()->timezone)) }}
                                                        </h5>
                                                        <h5 class=" text-muted" >{{ \Carbon\Carbon::createFromDate($sc->date_time)->diffForHumans() }}</h5>
                                                        <!--{{date('Y-m-d h:i a', strtotime($sc->date_time))}}-->
                                                        <!--@if(\Carbon\Carbon::parse($sc->date_time) <= \Carbon\Carbon::now())<a class=" color-1" href="{{ route('start.meeting',['id'=>$sc->id]) }}" style="text-decoration: none;" >Start Session</a>@endif-->
                                                        <a class=" color-1" target="_blank" href="{{ route('start.meeting',['id'=>$sc->id]) }}" style="text-decoration: none;" >Start Session</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                    @endforeach


                                @endif
                            </div>
                        </section>

                        @foreach($scheduals as $scr)
                                        <div class="modal fade" id="exampleModalenrol{{$scr->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h2 class="modal-title" id="exampleModalLabel">View Enrollment List</h2>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <form action="{{ route('create.group') }}" method="POST">
                                                    <div class="modal-body">
                                                        @forelse($scr->enrollments as $enr)
                                                            <ul>
                                                                <li>{{ $enr->name }}</li>
                                                            </ul>
                                                        @empty
                                                            <div class="row justify-content-center" style="display:flex; align-items:center;">
                                                                <p class="text-muted">No Enrollments Yet!</p>
                                                            </div>
                                                        @endforelse
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach


                        @if(auth()->user()->hasRole('user'))
                        <div class="row justify-content-center">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Hey {{ auth()->user()->name }}!</strong> A button to join the session will appear when your coach starts the class at the scheduled time.
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                        @endif

                        <!-------------------------------------------------calender--------------------->
                        <div class="row mt-4 mb-5 justify-content-center">
                            <div class="col-md-8 mt-3">
                                <div class="card shadow-card">
                                    <div class="card-body">
                                        <div class="row mb-3">
                                            <div class="col-md-8">
                                                <div>
                                                    <div id="basic" class="article">
                                                        <div class="calendar"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4 scroll-f" id="dispzone">
                                                <a style="float:right;" class="row p-0 m-0" href="{{ url('dashboard-home') }}">View All</a>
                                                <br/>
                                                @if($scheduals)
                                                @forelse($scheduals as $scr)
                                                    <div>
                                                        <h5 class="mt-2">
                                                            {{ date('d-M-Y',strtotime($scr->date_time.' '.auth()->user()->timezone)) }}
                                                            <span class="ml-4 text-muted" style="font-size: 12px;">
                                                                {{ date('h:i a',strtotime($scr->date_time.' '.auth()->user()->timezone)) }}
                                                            </span>
                                                        </h5>
                                                        <h6 class="text-muted">{{ $scr->title }}</h6>
                                                    </div>
                                                    <hr>
                                                @empty
                                                    <div class="row p-3 d-flex justify-content-center text-center h-100" style="align-items:center;">
                                                        <div>
                                                            <p class="text-muted">You haven’t signed up for any sessions. Learn more about coaching now!</p>
                                                            <a href="{{ url('/group-coaching') }}" class="btn default1 change mt-2">Explore Now</a>
                                                        </div>
                                                    </div>
                                                @endforelse
                                                @endif
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            @if(auth()->user()->hasRole('user') && $coach)

                                <div class="col-md-4 mt-3">
                                    <div class="card shadow-card">
                                        <div class="card-body">
                                            <h3 class=" font-weight-bold text-center">Your Coach</h3>
                                            <div class="text-center">
                                                <br/>
                                                <div style="width: 100px; height: 100px; border-radius: 10px; overflow: hidden;" class="m-auto">
                                                    <img style="object-position: center; object-fit: cover;" width="100%" src="{{ $coach->profile->image }}">
                                                </div>
                                                <h3 class=" mt-3">{{ $coach->name }}</h3>
                                                <!--<h4 class="text-muted">Effective speech in <br> larger audience</h4>-->
                                                <h5 class="font-weight-bold">{{ $coach->profile->city }}, {{ $coach->profile->country }}</h5>
                                                @if($session)
                                                    @if($session->is_group)
                                                        <!-- <a href="https://meet.google.com/iip-xucs-izy" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>-->
                                                        <a href="{{ route('call.group.caller',['id'=>$session->room_id]) }}" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>
                                                    @else
                                                        <!-- <a href="https://meet.google.com/iip-xucs-izy" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>-->
                                                        <a href="{{ route('call.caller',['id'=>$session->room_id]) }}" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>
                                                    @endif
                                                @else
                                                    <!-- <a href="https://meet.google.com/iip-xucs-izy" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>-->
                                                    <a href="{{ route('call.caller',['id'=>$coach->pivot->room_id]) }}" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>
                                                @endif

                                                    {{--  <a href="{{ route('call.end',['id'=>$session->room_id]) }}" class="btn default3 mt-4 mb-5">Start Session</a>--}}
                                                <a href="{{ url('check_and_schedule/'.$coach->id) }}"   class="btn default3 mt-4 mb-5">Check Availability & Schedule a Session</a>


                                            </div>
                                        </div>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                    </div>
                                </div>
                            @elseif(auth()->user()->hasRole('coach'))
                                <style>
                                    .green{
                                        background-color: #69d2b1;
                                    }
                                </style>
                                <div class="col-md-4 mt-3">
                                    <div class="row p-0 m-0">
                                        <div class="card shadow-card w-100">

                                            <div class="card-body">
                                                <h3 class="text-muted">Initialize a Session</h3>
                                                <div class=" d-flex align-items-center">
                                                    <button type="button" class="m-2 btn green text-white" style="" data-toggle="modal" data-target="#exampleModal">
                                                        Start a Group Call
                                                    </button>
                                                    <button type="button" class="m-2 btn green text-white" data-toggle="modal" data-target="#exampleModal2">
                                                        Schedule a Session
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br><br>
                                    <div class="row p-0 m-0">
                                        <div class="card shadow-card w-100">

                                            <div class="card-body">
                                                <h3 class="text-muted">Availability Setup </h3>
                                                <div class=" d-flex align-items-center">
                                                    <a href="{{url('coach-availability')}}" type="button" class="m-2 btn green text-white" style="">
                                                        Manage your availability
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @if($session)
                                    <div class="row p-0 m-0 mt-4">
                                        <div class="card shadow-card w-100">
                                            <div class="card-body">
                                                <h3 class="text-muted">You Have Session Running</h3>
                                                <div class="d-flex justify-content-center" style="flex-direction: row;">
                                                    @if($session)
                                                        @if($session->is_group)
                                                            <a href="{{ route('call.group.caller',['id'=>$session->room_id]) }}" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>
                                                        @else
                                                            <a href="{{ route('call.caller',['id'=>$session->room_id]) }}" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>
                                                        @endif
                                                    @else
                                                        <a href="{{ route('call.caller',['id'=>$session->room_id]) }}" target="_blank" @if($running) style="background-color: #1a7c00;" @endif class="btn default3 mt-4 mb-5">@if($running) Join Session @else Start Session @endif</a>
                                                    @endif
                                                            <a href="{{ route('end.session',['id'=>$session->room_id]) }}" @if($running) style="background-color: red; margin: 5px;" @endif class="btn default3 mt-4 mb-5">@if($running) End Session @else Start Session @endif</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            @endif
                        </div>
                        
                        
                    </div>
                </div>
                @else
                    <div class="col" style="height: 100vh;">
                        <div class="row h-100 justify-content-center flex">
                            <div class="col-auto align-self-center">
                                <div class="row justify-content-center p-3">
                                    <center><h2>You do not have any coaches. Let’s get started!</h2></center>
                                </div>
                                <br/>
                                <div class="row justify-content-center">
                                    <img src="https://d5qtswyw90myf.cloudfront.net/images/male-tutor.png" width="40%">
                                </div>
                                <br/><br/>
                                <div class="row justify-content-center">
{{--                                    <button class="btn default1 mt-4 mb-5 px-5 py-3" style="background-color: #69d2b1 !important; color: white !important;" data-toggle="modal" data-target="#exampleModalCenter">--}}
{{--                                        <strong>Get Started</strong>--}}
{{--                                    </button>--}}
                                    <a href="/coaching#price-table" class="btn default1 mt-4 mb-5 px-5 py-3" style="background-color: #69d2b1 !important; color: white !important;"><strong>Get Started</strong></a>

                                </div>
                            </div>
                        </div>

                    </div>
                @endif
            </div>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content  w-75 ml-5" style="border-radius: 25px;">
                <div class="modal-header">
                    <button type="button" class="close close-btn" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row ">
                            <div class="col-md-12">
                                <div class=" form-register" action="#" method="post">
                                    <div id="form-total">
                                        <!-- SECTION 1 -->
                                        <h1></h1>
                                        <section>
                                            <div class="row justify-content-center mt-4">
                                                <div class="col-md-12">
                                                    <h5 class="text-center  text-muted" style="font-size: 16px;">Why
                                                        would you like to be matched with a coach?</h5>
                                                    <div class="form-group mt-3">
                                                        <textarea class="form-control" id="message-text"
                                                            style="background-color:#ccc;"> </textarea>
                                                    </div>
                                                </div>

                                            </div>

                                        </section>
                                        <!-- SECTION 2 -->
                                        <h1></h1>
                                        <section>
                                            <div class="row justify-content-center">
                                                <div class="col-md-12 mt-3">
                                                    <h5 class="text-center  text-muted" style="font-size: 16px;">Do you
                                                        have any experience with public speaking or debate? If so, please
                                                        explain.</h5>
                                                    <div class="form-group mt-3">
                                                        <textarea class="form-control" id="message-text"
                                                            style="background-color:#ccc;"> </textarea>
                                                    </div>
                                                </div>

                                            </div>
                                        </section>
                                        <!-- SECTION 3 -->
                                        <h1></h1>
                                        <section>
                                            <div class="row justify-content-center">
                                                <div class="col-md-12 mt-4">
                                                    <div class="form-group mt-3 mb-5">
                                                        <div >
                                                            <h5 class="text-center  text-muted"
                                                                style="font-size: 16px;">You require a webcam and mic to effectively engage in sessions. Do you have access to a webcam and mic?</h5>
                                                            <input value="{{ csrf_token() }}" hidden type="text" id="csrf">

                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </section>

                                    </div>
                                </div>
                                <div id="lastmodal" style="display: none;">
                                    <div class="text-center">
                                        <img class="mt-1" src="images/tick mark.png">
                                    </div>
                                    <h5 class="text-center text-muted mt-4" style="font-size: 16px;">You are almost
                                        done!</h5>
                                    <div class="text-center">
                                        <a href="/coaching#price-table" class="btn default3 mt-5 mb-4">Select payment plan</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title" id="exampleModalLabel">Create Group</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('create.group') }}" method="POST">
                <div class="modal-body">
                    @if($students)
                            @csrf
                            <select class="selectpicker" multiple data-live-search="true" style="width:100%;" name="participents[]">
                                @foreach($students as $st)
                                    <option value="{{ $st->id }}">{{ $st->name }}</option>
                                @endforeach
                            </select>
                    @endif
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Go</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title" id="exampleModalLabel">Schedule a Meeting</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('create.schedual') }}" method="POST" id="form">
                    <div class="modal-body">
                        @if($students)
                            @csrf
                        <p class="text-muted m-0 p-0">Add Students(s)</p>
                            <select class="selectpicker" multiple data-live-search="true" name="participents[]" required>
                                @foreach($students as $st)
                                    <option value="{{ $st->id }}">{{ $st->name }}</option>
                                @endforeach
                            </select>
                        @endif
                        <div class="row p-0 m-0 mt-2">
                            <input type="text" name="title" class="form-control" required placeholder="Add Title">
                        </div>
                        <div class="row p-0 m-0 mt-2">
                            <textarea type="text" name="description" required class="form-control" placeholder="Add Description"></textarea>
                        </div>
                            <p class="text-muted m-0 p-0">Start Time</p>
                        <div class="row p-0 m-0 mt-2">
                            <input type="datetime-local" name="date_time" required class="form-control" placeholder="Strat Time">
                        </div>
                            <p class="text-muted m-0 p-0">End Time</p>
                            <div class="row p-0 m-0 mt-2">
                                <input type="datetime-local" name="end_time" required class="form-control" placeholder="End Time">
                            </div>
                            <p class="text-muted m-0 p-0">Time Zone</p>
                            <div class="row p-0 m-0 mt-2">
                                <select  name="time_zone" class="form-control">
                                    <option value="0">--select timezone--</option>
                                    <option value='Pacific/Midway' >(UTC-11:00) Midway Island</option>
                                    <option value='Pacific/Samoa' >(UTC-11:00) Samoa</option>
                                    <option value='Pacific/Honolulu' >(UTC-10:00) Hawaii</option>
                                    <option value='US/Alaska' >(UTC-09:00) Alaska</option>
                                    <option value='America/Los_Angeles' >(UTC-08:00) Pacific Time (US &amp; Canada)</option>
                                    <option value='America/Tijuana' >(UTC-08:00) Tijuana</option>
                                    <option value='US/Arizona' >(UTC-07:00) Arizona</option>
                                    <option value='America/Chihuahua' >(UTC-07:00) Chihuahua</option>
                                    <option value='America/Chihuahua' >(UTC-07:00) La Paz</option>
                                    <option value='America/Mazatlan' >(UTC-07:00) Mazatlan</option>
                                    <option value='US/Mountain' >(UTC-07:00) Mountain Time (US &amp; Canada)</option>
                                    <option value='America/Managua' >(UTC-06:00) Central America</option>
                                    <option value='US/Central' >(UTC-06:00) Central Time (US &amp; Canada)</option>
                                    <option value='America/Mexico_City' >(UTC-06:00) Guadalajara</option>
                                    <option value='America/Mexico_City' >(UTC-06:00) Mexico City</option>
                                    <option value='America/Monterrey' >(UTC-06:00) Monterrey</option>
                                    <option value='Canada/Saskatchewan' >(UTC-06:00) Saskatchewan</option>
                                    <option value='America/Bogota' >(UTC-05:00) Bogota</option>
                                    <option value='US/Eastern' >(UTC-05:00) Eastern Time (US &amp; Canada)</option>
                                    <option value='US/East-Indiana' >(UTC-05:00) Indiana (East)</option>
                                    <option value='America/Lima' >(UTC-05:00) Lima</option>
                                    <option value='America/Bogota' >(UTC-05:00) Quito</option>
                                    <option value='Canada/Atlantic' >(UTC-04:00) Atlantic Time (Canada)</option>
                                    <option value='America/Caracas' >(UTC-04:30) Caracas</option>
                                    <option value='America/La_Paz' >(UTC-04:00) La Paz</option>
                                    <option value='America/Santiago' >(UTC-04:00) Santiago</option>
                                    <option value='Canada/Newfoundland' >(UTC-03:30) Newfoundland</option>
                                    <option value='America/Sao_Paulo' >(UTC-03:00) Brasilia</option>
                                    <option value='America/Argentina/Buenos_Aires' >(UTC-03:00) Buenos Aires</option>
                                    <option value='America/Argentina/Buenos_Aires' >(UTC-03:00) Georgetown</option>
                                    <option value='America/Godthab' >(UTC-03:00) Greenland</option>
                                    <option value='America/Noronha' >(UTC-02:00) Mid-Atlantic</option>
                                    <option value='Atlantic/Azores' >(UTC-01:00) Azores</option>
                                    <option value='Atlantic/Cape_Verde' >(UTC-01:00) Cape Verde Is.</option>
                                    <option value='Africa/Casablanca' >(UTC+00:00) Casablanca</option>
                                    <option value='Europe/London' >(UTC+00:00) Edinburgh</option>
                                    <option value='Etc/Greenwich' >(UTC+00:00) Greenwich Mean Time : Dublin</option>
                                    <option value='Europe/Lisbon' >(UTC+00:00) Lisbon</option>
                                    <option value='Europe/London' >(UTC+00:00) London</option>
                                    <option value='Africa/Monrovia' >(UTC+00:00) Monrovia</option>
                                    <option value='UTC' >(UTC+00:00) UTC</option>
                                    <option value='Europe/Amsterdam' >(UTC+01:00) Amsterdam</option>
                                    <option value='Europe/Belgrade' >(UTC+01:00) Belgrade</option>
                                    <option value='Europe/Berlin' >(UTC+01:00) Berlin</option>
                                    <option value='Europe/Berlin' >(UTC+01:00) Bern</option>
                                    <option value='Europe/Bratislava' >(UTC+01:00) Bratislava</option>
                                    <option value='Europe/Brussels' >(UTC+01:00) Brussels</option>
                                    <option value='Europe/Budapest' >(UTC+01:00) Budapest</option>
                                    <option value='Europe/Copenhagen' >(UTC+01:00) Copenhagen</option>
                                    <option value='Europe/Ljubljana' >(UTC+01:00) Ljubljana</option>
                                    <option value='Europe/Madrid' >(UTC+01:00) Madrid</option>
                                    <option value='Europe/Paris' >(UTC+01:00) Paris</option>
                                    <option value='Europe/Prague' >(UTC+01:00) Prague</option>
                                    <option value='Europe/Rome' >(UTC+01:00) Rome</option>
                                    <option value='Europe/Sarajevo' >(UTC+01:00) Sarajevo</option>
                                    <option value='Europe/Skopje' >(UTC+01:00) Skopje</option>
                                    <option value='Europe/Stockholm' >(UTC+01:00) Stockholm</option>
                                    <option value='Europe/Vienna' >(UTC+01:00) Vienna</option>
                                    <option value='Europe/Warsaw' >(UTC+01:00) Warsaw</option>
                                    <option value='Africa/Lagos' >(UTC+01:00) West Central Africa</option>
                                    <option value='Europe/Zagreb' >(UTC+01:00) Zagreb</option>
                                    <option value='Europe/Athens' >(UTC+02:00) Athens</option>
                                    <option value='Europe/Bucharest' >(UTC+02:00) Bucharest</option>
                                    <option value='Africa/Cairo' >(UTC+02:00) Cairo</option>
                                    <option value='Africa/Harare' >(UTC+02:00) Harare</option>
                                    <option value='Europe/Helsinki' >(UTC+02:00) Helsinki</option>
                                    <option value='Europe/Istanbul' >(UTC+02:00) Istanbul</option>
                                    <option value='Asia/Jerusalem' >(UTC+02:00) Jerusalem</option>
                                    <option value='Europe/Helsinki' >(UTC+02:00) Kyiv</option>
                                    <option value='Africa/Johannesburg' >(UTC+02:00) Pretoria</option>
                                    <option value='Europe/Riga' >(UTC+02:00) Riga</option>
                                    <option value='Europe/Sofia' >(UTC+02:00) Sofia</option>
                                    <option value='Europe/Tallinn' >(UTC+02:00) Tallinn</option>
                                    <option value='Europe/Vilnius' >(UTC+02:00) Vilnius</option>
                                    <option value='Asia/Baghdad' >(UTC+03:00) Baghdad</option>
                                    <option value='Asia/Kuwait' >(UTC+03:00) Kuwait</option>
                                    <option value='Europe/Minsk' >(UTC+03:00) Minsk</option>
                                    <option value='Africa/Nairobi' >(UTC+03:00) Nairobi</option>
                                    <option value='Asia/Riyadh' >(UTC+03:00) Riyadh</option>
                                    <option value='Europe/Volgograd' >(UTC+03:00) Volgograd</option>
                                    <option value='Asia/Tehran' >(UTC+03:30) Tehran</option>
                                    <option value='Asia/Muscat' >(UTC+04:00) Abu Dhabi</option>
                                    <option value='Asia/Baku' >(UTC+04:00) Baku</option>
                                    <option value='Europe/Moscow' >(UTC+04:00) Moscow</option>
                                    <option value='Asia/Muscat' >(UTC+04:00) Muscat</option>
                                    <option value='Europe/Moscow' >(UTC+04:00) St. Petersburg</option>
                                    <option value='Asia/Tbilisi' >(UTC+04:00) Tbilisi</option>
                                    <option value='Asia/Yerevan' >(UTC+04:00) Yerevan</option>
                                    <option value='Asia/Kabul' >(UTC+04:30) Kabul</option>
                                    <option value='Asia/Karachi' >(UTC+05:00) Islamabad</option>
                                    <option value='Asia/Karachi' >(UTC+05:00) Karachi</option>
                                    <option value='Asia/Tashkent' >(UTC+05:00) Tashkent</option>
                                    <option value='Asia/Calcutta' >(UTC+05:30) Chennai</option>
                                    <option value='Asia/Kolkata' >(UTC+05:30) Kolkata</option>
                                    <option value='Asia/Calcutta' >(UTC+05:30) Mumbai</option>
                                    <option value='Asia/Calcutta' >(UTC+05:30) New Delhi</option>
                                    <option value='Asia/Calcutta' >(UTC+05:30) Sri Jayawardenepura</option>
                                    <option value='Asia/Katmandu' >(UTC+05:45) Kathmandu</option>
                                    <option value='Asia/Almaty' >(UTC+06:00) Almaty</option>
                                    <option value='Asia/Dhaka' >(UTC+06:00) Astana</option>
                                    <option value='Asia/Dhaka' >(UTC+06:00) Dhaka</option>
                                    <option value='Asia/Yekaterinburg' >(UTC+06:00) Ekaterinburg</option>
                                    <option value='Asia/Rangoon' >(UTC+06:30) Rangoon</option>
                                    <option value='Asia/Bangkok' >(UTC+07:00) Bangkok</option>
                                    <option value='Asia/Bangkok' >(UTC+07:00) Hanoi</option>
                                    <option value='Asia/Jakarta' >(UTC+07:00) Jakarta</option>
                                    <option value='Asia/Novosibirsk' >(UTC+07:00) Novosibirsk</option>
                                    <option value='Asia/Hong_Kong' >(UTC+08:00) Beijing</option>
                                    <option value='Asia/Chongqing' >(UTC+08:00) Chongqing</option>
                                    <option value='Asia/Hong_Kong' >(UTC+08:00) Hong Kong</option>
                                    <option value='Asia/Krasnoyarsk' >(UTC+08:00) Krasnoyarsk</option>
                                    <option value='Asia/Kuala_Lumpur' >(UTC+08:00) Kuala Lumpur</option>
                                    <option value='Australia/Perth' >(UTC+08:00) Perth</option>
                                    <option value='Asia/Singapore' >(UTC+08:00) Singapore</option>
                                    <option value='Asia/Taipei' >(UTC+08:00) Taipei</option>
                                    <option value='Asia/Ulan_Bator' >(UTC+08:00) Ulaan Bataar</option>
                                    <option value='Asia/Urumqi' >(UTC+08:00) Urumqi</option>
                                    <option value='Asia/Irkutsk' >(UTC+09:00) Irkutsk</option>
                                    <option value='Asia/Tokyo' >(UTC+09:00) Osaka</option>
                                    <option value='Asia/Tokyo' >(UTC+09:00) Sapporo</option>
                                    <option value='Asia/Seoul' >(UTC+09:00) Seoul</option>
                                    <option value='Asia/Tokyo' >(UTC+09:00) Tokyo</option>
                                    <option value='Australia/Adelaide' >(UTC+09:30) Adelaide</option>
                                    <option value='Australia/Darwin' >(UTC+09:30) Darwin</option>
                                    <option value='Australia/Brisbane' >(UTC+10:00) Brisbane</option>
                                    <option value='Australia/Canberra' >(UTC+10:00) Canberra</option>
                                    <option value='Pacific/Guam' >(UTC+10:00) Guam</option>
                                    <option value='Australia/Hobart' >(UTC+10:00) Hobart</option>
                                    <option value='Australia/Melbourne' >(UTC+10:00) Melbourne</option>
                                    <option value='Pacific/Port_Moresby' >(UTC+10:00) Port Moresby</option>
                                    <option value='Australia/Sydney' >(UTC+10:00) Sydney</option>
                                    <option value='Asia/Yakutsk' >(UTC+10:00) Yakutsk</option>
                                    <option value='Asia/Vladivostok' >(UTC+11:00) Vladivostok</option>
                                    <option value='Pacific/Auckland' >(UTC+12:00) Auckland</option>
                                    <option value='Pacific/Fiji' >(UTC+12:00) Fiji</option>
                                    <option value='Pacific/Kwajalein' >(UTC+12:00) International Date Line West</option>
                                    <option value='Asia/Kamchatka' >(UTC+12:00) Kamchatka</option>
                                    <option value='Asia/Magadan' >(UTC+12:00) Magadan</option>
                                    <option value='Pacific/Fiji' >(UTC+12:00) Marshall Is.</option>
                                    <option value='Asia/Magadan' >(UTC+12:00) New Caledonia</option>
                                    <option value='Asia/Magadan' >(UTC+12:00) Solomon Is.</option>
                                    <option value='Pacific/Auckland' >(UTC+12:00) Wellington</option>
                                    <option value='Pacific/Tongatapu' >(UTC+13:00) Nuku'alofa</option>
                                </select>
                            </div>

                            <p class="text-muted m-0 p-0">Recurring Type</p>
                            <div class="row p-0 m-0 mt-2">
                                <select name="recurring_type" class="form-control">
                                    <option value="0">One Time</option>
                                    <option value="3">Monthly</option>
                                    <option value="2">Biweekly</option>
                                    <option value="1">Weekly</option>
                                </select>
                            </div>

                            <div class="row p-0 m-0 mt-2">
                                <select name="is_group" class="form-control">
                                    <option value="1">Private session</option>
                                    <option value="2">Group session</option>
                                </select>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-----------------------drop down script--------------------------->
    <script>
        /* When the user clicks on the button,
        toggle between hiding and showing the dropdown content */
        function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function (event) {
            if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
        document.getElementById("myDropdown").addEventListener('click', function (event) {
            event.stopPropagation();
        });
    </script>
    <!-------------------------------tab script-------------->
    <!--script carousal slider-->
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="{{asset('dashboard/slick/slick.js')}}" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
        $(document).on('ready', function () {

            $('#id_select').selectpicker();
            $('#id_selectt').selectpicker();

            $(".center").slick({
                dots: false,
                infinite: true,
                centerMode: true,
                slidesToShow: 3,
                slidesToScroll: 2,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            infinite: true,
                            dots: false,
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 0,
                        }
                    }
                    // You can unslick at a given breakpoint now by adding:
                    // settings: "unslick"
                    // instead of a settings object
                ]
            });

        });
    </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- <script src="js/jquery-3.3.1.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
    <script src="{{ asset('dashboard/js/jquery.steps.js') }}"></script>
    <script src="{{ asset('dashboard/js/main.js') }}"></script>
    <script src="{{ asset('dashboard/js/fm.selectator.jquery.js') }}"></script>
    <script src="{{ asset('admin/js/plugins/extensions/jquery_ui/interactions.min.js')}}"></script>
    <script src="{{ asset('admin/js/plugins/forms/selects/select2.min.js') }}"></script>
    <script src="{{ asset('admin/js/demo_pages/form_select2.js') }}"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
    <!--steps-->
    <script>
        $(document).ready(function () {


            $("#form-total-t-1").click(function () {
                // alert("The paragraph was clicked.");
                $("div.actions").children().css('display', "inline-block");
            });

            $('a[href^="#finish"]').click(function () {
                $("#form-total").hide();
                $("#lastmodal").show();
            });
        })

    </script>
    <!--calender-->
    <script type="text/javascript" src="{{ asset('dashboard/dist/js/pignose.calendar.full.min.js') }}"></script>
     <script type="text/javascript">
        //<![CDATA[
        $(function () {
            $('#wrapper .version strong').text('v' + $.fn.pignoseCalendar.version);

            function onSelectHandler(date, context) {
                /**
                 * @date is an array which be included dates(clicked date at first index)
                 * @context is an object which stored calendar interal data.
                 * @context.calendar is a root element reference.
                 * @context.calendar is a calendar element reference.
                 * @context.storage.activeDates is all toggled data, If you use toggle type calendar.
                 * @context.storage.events is all events associated to this date
                 */
                //  alert(date)
                var $element = context.element;
                var $calendar = context.calendar;
                var $box = $element.siblings('.box').show();
                var text = 'You selected date ';

                if (date[0] !== null) {
                    text += date[0].format('YYYY-MM-DD');
                }

                if (date[0] !== null && date[1] !== null) {
                    text += ' ~ ';
                }
                else if (date[0] === null && date[1] == null) {
                    text += 'nothing';
                }

                if (date[1] !== null) {
                    text += date[1].format('YYYY-MM-DD');
                }

                $.ajax({
                    method:"post",
                    url:"{{ url('/get-classes') }}",
                    data:{
                        _token:'{{ csrf_token() }}',
                        date:date[0].format('YYYY-MM-DD')
                    },
                    success:function(data){
                        let datal = '<a style="float:right;" class="row p-0 m-0" href="{{ url('dashboard-home') }}">View All</a><br/>'
                        data.forEach(obj=>{
                            datal += '<div><h5 class="mt-2">'+obj.date+'<span class="ml-4 text-muted" style="font-size: 12px;">'+obj.time+'</span></h5><h6 class="text-muted">'+obj.title+'</h6></div><hr>'
                        })
                        document.getElementById('dispzone').innerHTML = datal
                    },
                    error:function(error){

                    }
                })

                $box.text(text);
            }

            function onApplyHandler(date, context) {
                /**
                 * @date is an array which be included dates(clicked date at first index)
                 * @context is an object which stored calendar interal data.
                 * @context.calendar is a root element reference.
                 * @context.calendar is a calendar element reference.
                 * @context.storage.activeDates is all toggled data, If you use toggle type calendar.
                 * @context.storage.events is all events associated to this date
                 */

                var $element = context.element;
                var $calendar = context.calendar;
                var $box = $element.siblings('.box').show();
                var text = 'You applied date ';

                if (date[0] !== null) {
                    text += date[0].format('YYYY-MM-DD');
                }

                if (date[0] !== null && date[1] !== null) {
                    text += ' ~ ';
                }
                else if (date[0] === null && date[1] == null) {
                    text += 'nothing';
                }

                if (date[1] !== null) {
                    text += date[1].format('YYYY-MM-DD');
                }

                $box.text(text);
            }

            // Default Calendar
            $('.calendar').pignoseCalendar({
                select: onSelectHandler,
                schedules: [
                    @forelse($scheduals as $scr)
                        @php echo "{
                            name:'holiday',
                            date:'".date('Y-m-d',strtotime($scr->date_time))."'
                        },";
                        @endphp
                    @endforeach
                ],
                    scheduleOptions: {
                        colors: {
                            holiday: '#2fabb7',
                            seminar: '#5c6270',
                            meetup: '#ef8080',
                        }
                    }
            });

            // This use for DEMO page tab component.
            $('.menu .item').tab();
        });
    //]]>
        //// end
    </script>
@endsection
